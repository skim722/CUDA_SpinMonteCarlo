
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <float.h>
#include <string>
#include <assert.h>
#include "heisenberg.h"
#include "Reader.h"

using namespace std;




InputParameters readInputs(int argc, char* argv[])
{
  if(argc == 1)
  {
    cout << "Input file not found. Please execute program as follows: '" << argv[0] << " inputFileName'" << endl;
    cout << "Exiting." << endl;
    exit(EXIT_FAILURE);
  }
  else
  {
    string inputFileName(argv[1]);
    Reader reader(inputFileName);
    return reader.inputs;
  }
}
void cpu_simulation_original(int MCSteps)
{
	//Calculate delta_max
	double delta_max;
	//   delta_max = 0.1;
	//   //TODO: Need to fix. Seems optimization is not work. (Rooms for improvement) 
	//   for (int i=0;i<5000;i++){
	//          double ratio;
	//          ratio = oneMonteCarloStepPerSpin(delta_max);
	//           if     (ratio<0.30) {delta_max*=0.90;}
	//           else if(ratio<0.45) {delta_max*=0.99;}
	//           else if(ratio>0.70) {delta_max*=1.10;}
	//           else if(ratio>0.55) {delta_max*=1.01;}
	//          if (delta_max>0.5) {delta_max = 0.5;break;}
	//          cout << "T "<< T << " trial step size " << delta_max << " " << ratio << endl;
	//     }
	//   cout<<"optimized delta_max:  "<<delta_max<<endl;
	delta_max=0.5;                                        // TODO: delete later 
	ofstream file("heisenberg_quenching.data");
	//file << " L(Box Size): " << Lx <<'\t' << " H(Magnetic Field): " << H <<'\t'<<" MCSteps: "<< MCSteps << endl;
	file << " L(Box Size): " << Lx <<'\t' << " H(Magnetic Field): " << scientific;
	for (int l=0;l<DIMENSIONS;l++) file << H[l] << " ";
	file <<'\t'<<" MCSteps: "<< MCSteps << endl;


	int thermSteps = int(0.2 * MCSteps);

	for (int t=0;t<200;t++){
		double mAv = 0, m2Av = 0, eAv = 0, e2Av = 0, MAv=0;
		for (int i = 0; i < thermSteps; i++){
			oneMonteCarloStepPerSpin(delta_max,T);
		}

		for (int mc_n = 0; mc_n < MCSteps; mc_n++) {
			oneMonteCarloStepPerSpin(delta_max,T);
			double m = fabs(magnetizationPerSpin());
			double M = fabs(magnetization());
			double e = energyPerSpin();
			MAv +=M;
			mAv += m; m2Av += m * m;
			eAv += e; e2Av += e * e;
		}

		mAv /= MCSteps; m2Av /= MCSteps;
		eAv /= MCSteps; e2Av /= MCSteps;
		MAv /= MCSteps;

		cout <<"iteration number : "<<t<<"\n"<<endl;
		cout <<"T ="<<'\t'<<T<< " <m> = "<<'\t' << mAv << " +/- " << sqrt(fabs(m2Av - mAv*mAv)) <<'\t'<<  " <e> = " <<'\t'<< eAv << " +/- " << sqrt(e2Av - eAv*eAv) << endl;
		file <<"T"<<'\t'<<  T <<'\t' << " <m> " <<'\t'<< mAv <<"   "<<'\t'<<"M"<<'\t'<<MAv<< endl;

		T=T-(T/1000)*(t);
	}

	cout << " \n Magnetization and energy per spin written in file "
	<< " \"heisenberg_quencing.data\"" << endl;
	file.close();
}

void cpu_simulation_timing(int MCSteps)
{
	double delta_max = 0.5;
	int thermSteps = int(0.2 * MCSteps);
	for (int t=0;t<200;t++){
		for (int i = 0; i < thermSteps; i++)
		{
			oneMonteCarloStepPerSpin(delta_max,T);
		}
		for (int mc_n = 0; mc_n < MCSteps; mc_n++)
		{
			oneMonteCarloStepPerSpin(delta_max,T);
		}
		cout <<"iteration number : "<<t<<"\n"<<endl;
		T=T-(T/1000)*(t);
	}
}

double gpu_simulation_timing(int MCSteps);

int main (int argc, char *argv[])
{
	srand(time(NULL)); 
	cout << " Three-dimensional Heisenberg Model - Metropolis simulation\n"
		<< " ---------------------------------------------------\n";

	InputParameters inputs = readInputs(argc,argv);
	Lx = inputs.Lx;
	Ly = inputs.Ly;
	Lz = inputs.Lz;
	N = Lx*Ly*Lz;
	double h = inputs.magneticField;
	double MCSteps = inputs.MonteCarloSteps;
	T = inputs.highestTemperature;

	initialize();

	// define H vector
	for (int l=0;l<DIMENSIONS;l++) H[l] = h*isingAxis[l];

	stepTiming();

}

